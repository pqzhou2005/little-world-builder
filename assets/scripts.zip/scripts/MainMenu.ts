import { _decorator, Component, Node, Label, director } from 'cc';
import { GameLaunchParams, LaunchMode } from './core/GameLaunchParams';
import { GameCore } from './core/GameCore';

const { ccclass, property } = _decorator;

@ccclass('MainMenu')
export class MainMenu extends Component {

    @property(Node)
    btnMain!: Node;

    @property(Node)
    btnRestart!: Node;

    @property(Label)
    mainLabel!: Label;

    private chapterId = 'chapter-1';

    start () {
        const hasSave = GameCore.hasSave(this.chapterId);

        // 主按钮文字
        this.mainLabel.string = hasSave ? '继续游戏' : '开始游戏';

        // 是否显示「重新开始」
        this.btnRestart.active = hasSave;
    }

    onMainClick () {
        const hasSave = GameCore.hasSave(this.chapterId);

        GameLaunchParams.mode = hasSave
            ? LaunchMode.Continue
            : LaunchMode.NewGame;

        GameLaunchParams.chapterId = this.chapterId;
        director.loadScene('Game');
    }

    onRestartClick () {
        GameLaunchParams.mode = LaunchMode.Restart;
        GameLaunchParams.chapterId = this.chapterId;
        director.loadScene('Game');
    }
}
