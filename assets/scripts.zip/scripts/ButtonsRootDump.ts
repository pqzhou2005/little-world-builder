import { _decorator, Component, Layout } from 'cc';
const { ccclass } = _decorator;

function stack(tag: string) {
  const e = new Error(tag);
  return e.stack || '(no stack)';
}

@ccclass('LayoutWhoSetCell')
export class LayoutWhoSetCell extends Component {
  start() {
    const layout = this.getComponent(Layout);
    if (!layout) {
      console.log('[LayoutWhoSetCell] no Layout on this node');
      return;
    }

    const anyL: any = layout;

    console.log('\n==== LayoutWhoSetCell HOOKED ====');
    console.log('node=', this.node.name);
    console.log('initial cellSize=', anyL.cellSize);
    console.log('initial constraintNum=', anyL.constraintNum);
    console.log('initial spacing=', anyL.spacingX ?? anyL.spacing);
    console.log('=================================\n');

    // Hook cellSize setter (通过 defineProperty 拦截)
    let _cell = anyL.cellSize;
    Object.defineProperty(anyL, 'cellSize', {
      get() { return _cell; },
      set(v) {
        console.log('\n[LayoutWhoSetCell] layout.cellSize SET =>', v);
        console.log(stack('[cellSize set stack]'));
        _cell = v;
      }
    });

    // Hook constraintNum
    if ('constraintNum' in anyL) {
      let _cn = anyL.constraintNum;
      Object.defineProperty(anyL, 'constraintNum', {
        get() { return _cn; },
        set(v) {
          console.log('\n[LayoutWhoSetCell] layout.constraintNum SET =>', v);
          console.log(stack('[constraintNum set stack]'));
          _cn = v;
        }
      });
    }

    // Hook updateLayout（有人主动调用也能抓到）
    if (typeof anyL.updateLayout === 'function') {
      const orig = anyL.updateLayout.bind(layout);
      anyL.updateLayout = () => {
        console.log('\n[LayoutWhoSetCell] layout.updateLayout() called');
        console.log(stack('[updateLayout stack]'));
        return orig();
      };
    }
  }
}
