import type { ChapterTemplate, ChapterState } from '../data/chapterTemplates';

export type CombineResult =
  | { ok: true; result: string; reason: string; isNew: boolean }
  | { ok: false };

function makeKey(a: string, b: string) {
  return [a, b].sort().join('+');
}

export class GameCore {
  private rulesMap = new Map<string, { result: string; reason: string }>();

  // 这里复刻你 web 版的状态结构：owned + ownedOrder
  public owned = new Set<string>();
  public ownedOrder: string[] = [];

  public currentGoalIndex = 0;

  constructor(public template: ChapterTemplate, private templateId: string) {
    // init owned
    for (const e of template.initialElements ?? []) {
      this.addNewElement(e, { silent: true });
    }

    // rules
    for (const r of template.rules ?? []) {
      const key = makeKey(r.ingredients[0], r.ingredients[1]);
      this.rulesMap.set(key, { result: r.result, reason: r.reason });
    }

    // init goals progress
    this.advanceGoalsIfNeeded();
  }

  /** 给 goals.completeWhen 使用的 state（你模板需要 owned: Set<string>） */
  public getChapterState(): ChapterState {
    return { owned: this.owned };
  }

  public has(name: string) {
    return this.owned.has(name);
  }

  public addNewElement(name: string, opts?: { silent?: boolean }): boolean {
    if (this.owned.has(name)) return false;
    this.owned.add(name);
    this.ownedOrder.push(name);
    if (!opts?.silent) {
      this.advanceGoalsIfNeeded();
    }
    return true;
  }

  public tryCombine(a: string, b: string): CombineResult {
    const key = makeKey(a, b);
    const rule = this.rulesMap.get(key);
    if (!rule) return { ok: false };

    const isNew = this.addNewElement(rule.result);
    // 合成后推进目标（如果 result 是新元素才推进也可以；这里统一推进一次）
    this.advanceGoalsIfNeeded();

    return { ok: true, result: rule.result, reason: rule.reason, isNew };
  }

  public getCurrentGoalText(): string {
    const goals = this.template.goals ?? [];
    if (this.currentGoalIndex < goals.length) {
      return goals[this.currentGoalIndex].text;
    }
    // goals 全完成后：自由探索提示（取第一句就行，后面再做轮换）
    return (this.template.freeExploreMessages?.[0]) ?? '随便试试不同的组合吧～';
  }

  public advanceGoalsIfNeeded(): number[] {
    const completed: number[] = [];
    const goals = this.template.goals ?? [];
    while (this.currentGoalIndex < goals.length) {
      const g = goals[this.currentGoalIndex];
      const done = g.completeWhen(this.getChapterState());
      if (!done) break;
      completed.push(g.id);
      this.currentGoalIndex += 1;
    }
    return completed;
  }

  public isChapterCompleted(): boolean {
    return this.currentGoalIndex >= (this.template.goals?.length ?? 0);
  }

  private getSaveKey() {
    return `qp-save-${this.templateId}`;
  }

  public static hasSave(templateId: string): boolean {
    return localStorage.getItem(`qp-save-${templateId}`) !== null;
  }


  public save() {
    const data = {
      owned: this.ownedOrder,
      goalIndex: this.currentGoalIndex,
    };
    try {
      localStorage.setItem(this.getSaveKey(), JSON.stringify(data));
    } catch {}
  }

  public load() {
    const raw = localStorage.getItem(this.getSaveKey());
    if (!raw) return;
    try {
      const data = JSON.parse(raw);
      if (Array.isArray(data.owned)) {
        this.owned = new Set(data.owned);
        this.ownedOrder = data.owned.slice();
      }
      if (typeof data.goalIndex === 'number') {
        this.currentGoalIndex = data.goalIndex;
      }
    } catch {}
  }
}
