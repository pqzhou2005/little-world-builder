export enum LaunchMode {
  NewGame,
  Continue,
  Restart,
}

export class GameLaunchParams {
  static mode: LaunchMode = LaunchMode.NewGame;
  static chapterId: string = 'chapter-1';
}