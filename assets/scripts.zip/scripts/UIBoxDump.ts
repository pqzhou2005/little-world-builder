import { _decorator, Component, Node, UITransform, Widget, Mask, Vec3 } from 'cc';
const { ccclass } = _decorator;

function pathOf(n: Node | null) {
  if (!n) return 'null';
  const names: string[] = [];
  let cur: Node | null = n;
  while (cur) { names.push(cur.name); cur = cur.parent; }
  return '/' + names.reverse().join('/');
}

function dumpNode(tag: string, n: Node | null) {
  if (!n) {
    console.log(`[UIBoxDump] ${tag}: null`);
    return;
  }
  const ui = n.getComponent(UITransform);
  const w = n.getComponent(Widget);
  const m = n.getComponent(Mask);

  const local = n.position;
  const world = n.worldPosition;
  const size = ui?.contentSize;
  const anchor = ui?.anchorPoint;
  const wb = ui ? ui.getBoundingBoxToWorld() : null;

  console.log(`\n[UIBoxDump] === ${tag} ===`);
  console.log('name=', n.name, 'path=', pathOf(n));
  console.log('localPos=', local, 'worldPos=', world);
  console.log('size/anchor=', size, anchor);
  console.log('worldBox=', wb ? `x=${wb.x.toFixed(1)} y=${wb.y.toFixed(1)} w=${wb.width.toFixed(1)} h=${wb.height.toFixed(1)}` : 'null');
  console.log('hasMask=', !!m);

  if (w) {
    console.log('[Widget]',
      'enabled=', w.enabled,
      'left=', w.isAlignLeft, w.left,
      'right=', w.isAlignRight, w.right,
      'top=', w.isAlignTop, w.top,
      'bottom=', w.isAlignBottom, w.bottom,
      'target=', w.target ? w.target.name : 'null',
      'alignMode=', w.alignMode
    );
  } else {
    console.log('[Widget] null');
  }
  console.log(`[UIBoxDump] === END ${tag} ===\n`);
}

@ccclass('UIBoxDump')
export class UIBoxDump extends Component {
  start() {
    this.scheduleOnce(() => this.run(), 0);
    this.scheduleOnce(() => this.run(), 0.2); // 再打一遍，防止 Widget/SafeArea 后更新
  }

  private findByPath(path: string): Node | null {
    // path like "SafeRoot/ButtonsPannel/ScrollView"
    let cur: Node | null = this.node;
    const parts = path.split('/').filter(Boolean);
    for (const p of parts) {
      if (!cur) return null;
      cur = cur.getChildByName(p);
    }
    return cur;
  }

  private run() {
    // 你把这个脚本挂在 Canvas 或 SafeRoot，都能用：
    // 如果挂在 Canvas：path 从 "SafeRoot/..." 开始
    // 如果挂在 SafeRoot：path 从 "ButtonsPannel/..." 开始
    const baseIsCanvas = this.node.getChildByName('SafeRoot') != null;
    const base = baseIsCanvas ? this.node : (this.node.parent?.getChildByName('Canvas') ? this.node.parent!.getChildByName('Canvas')! : this.node);

    const canvas = baseIsCanvas ? this.node : (this.node.name === 'Canvas' ? this.node : base);
    const safeRoot = baseIsCanvas ? this.node.getChildByName('SafeRoot') : (this.node.name === 'SafeRoot' ? this.node : this.node.getChildByName('SafeRoot'));

    // 尝试按你的层级找
    const buttonsPannel = safeRoot ? safeRoot.getChildByName('ButtonsPannel') : null;
    const scrollView = buttonsPannel ? buttonsPannel.getChildByName('ScrollView') : null;
    const viewport = scrollView ? scrollView.getChildByName('Viewport') : null;
    const content = viewport ? viewport.getChildByName('ButtonsRoot') : (scrollView ? scrollView.getChildByName('ButtonsRoot') : null);
    const bg = buttonsPannel ? buttonsPannel.getChildByName('Bg') : null;

    console.log('\n================ UIBoxDump RUN ================');
    dumpNode('Canvas', canvas);
    dumpNode('SafeRoot', safeRoot);
    dumpNode('ButtonsPannel', buttonsPannel);
    dumpNode('ButtonsPannel/Bg', bg);
    dumpNode('ScrollView', scrollView);
    dumpNode('Viewport', viewport);
    dumpNode('ButtonsRoot(Content)', content);

    // 顺便打一个最下面/最右边的按钮，确认它在面板内
    if (content && content.children.length) {
      const last = content.children[content.children.length - 1];
      dumpNode('LastChild', last);
    }
    console.log('================ END UIBoxDump ================\n');
  }
}
