import { _decorator, Component, Node, UITransform, ScrollView, Mask, Widget, Layout } from 'cc';
const { ccclass } = _decorator;

function pathOf(n: Node) {
  const arr: string[] = [];
  let cur: Node | null = n;
  while (cur) { arr.push(cur.name); cur = cur.parent; }
  return '/' + arr.reverse().join('/');
}

function boxStr(n: Node) {
  const ui = n.getComponent(UITransform);
  if (!ui) return 'no UITransform';
  const b = ui.getBoundingBoxToWorld();
  return `x=${b.x.toFixed(1)} y=${b.y.toFixed(1)} w=${b.width.toFixed(1)} h=${b.height.toFixed(1)}`;
}

function dumpNode(tag: string, n: Node | null) {
  if (!n) { console.log(`[TreeDump] ${tag}: null`); return; }
  const ui = n.getComponent(UITransform);
  const w  = n.getComponent(Widget);
  const m  = n.getComponent(Mask);
  const sv = n.getComponent(ScrollView);
  const l  = n.getComponent(Layout);

  console.log(`\n[TreeDump] === ${tag} ===`);
  console.log('name=', n.name);
  console.log('path=', pathOf(n));
  console.log('worldBox=', boxStr(n));
  if (ui) console.log('ui.size/anchor=', ui.contentSize, ui.anchorPoint);
  console.log('has ScrollView=', !!sv, 'has Mask=', !!m, 'has Widget=', !!w, 'has Layout=', !!l);
  if (sv) console.log('sv.content=', sv.content?.name);
  if (w) console.log('widget target=', w.target?.name, 'L/R/T/B=', w.isAlignLeft, w.left, w.isAlignRight, w.right, w.isAlignTop, w.top, w.isAlignBottom, w.bottom);
  console.log(`[TreeDump] === END ${tag} ===\n`);
}

@ccclass('ScrollTreeDump')
export class ScrollTreeDump extends Component {
  start() {
    // 从挂载点往下搜 ScrollView（不靠路径）
    const svNode = this.findFirstScrollView(this.node);
    dumpNode('AttachRoot', this.node);
    dumpNode('FoundScrollViewNode', svNode);

    if (!svNode) return;

    // 经典结构：ScrollView -> Viewport -> Content
    const sv = svNode.getComponent(ScrollView)!;

    // sv.content 指向 Content（ButtonsRoot）
    const content = sv.content;
    dumpNode('Content(sv.content)', content);

    // 视窗节点：优先找名为 Viewport 的子节点；找不到就找带 Mask 的那个
    const viewportByName = svNode.getChildByName('Viewport');
    const viewportByMask = this.findChildWithMask(svNode);
    dumpNode('Viewport(byName)', viewportByName);
    dumpNode('Viewport(byMask)', viewportByMask);

    // 如果 content 存在，顺便列一下 content 的前几个 child，看看排版是不是正常
    if (content) {
      console.log(`[TreeDump] Content children=${content.children.length}`);
      for (let i = 0; i < Math.min(8, content.children.length); i++) {
        dumpNode(`ContentChild#${i}`, content.children[i]);
      }
    }
  }

  private findFirstScrollView(root: Node): Node | null {
    if (root.getComponent(ScrollView)) return root;
    for (const c of root.children) {
      const r = this.findFirstScrollView(c);
      if (r) return r;
    }
    return null;
  }

  private findChildWithMask(root: Node): Node | null {
    if (root.getComponent(Mask)) return root;
    for (const c of root.children) {
      const r = this.findChildWithMask(c);
      if (r) return r;
    }
    return null;
  }
}
