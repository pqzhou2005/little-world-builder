import { _decorator, Component, Node, Label, Button, Prefab, instantiate } from 'cc';
import { GameCore } from './core/GameCore';
import { chapterTemplates, ELEMENT_ICONS } from './data/chapterTemplates';

const { ccclass, property } = _decorator;

@ccclass('QuickPlayController')
export class QuickPlayController extends Component {
  @property(Node)
  buttonsRoot: Node | null = null;

  @property(Prefab)
  elementButtonPrefab: Prefab | null = null;

  @property(Label)
  slotALabel: Label | null = null;

  @property(Label)
  slotBLabel: Label | null = null;

  @property(Label)
  goalLabel: Label | null = null;

  @property(Node)
  popup: Node | null = null;

  @property(Label)
  popupTitle: Label | null = null;

  @property(Label)
  popupDesc: Label | null = null;

  @property(Button)
  popupCloseBtn: Button | null = null;

  private core!: GameCore;
  private slotA: string | null = null;
  private slotB: string | null = null;

  start() {
    if (
      !this.buttonsRoot ||
      !this.elementButtonPrefab ||
      !this.slotALabel ||
      !this.slotBLabel
    ) {
      console.warn('QuickPlayController: missing required refs');
      return;
    }

    // popup close
    if (this.popup && this.popupCloseBtn) {
      this.popup.active = false;
      this.popupCloseBtn.node.on(Button.EventType.CLICK, () => {
        if (this.popup) this.popup.active = false;
      });
    }

    (globalThis as any).showChapterCompleteScreen = (chapterId: string) => {
      this.showPopup('🎉 章节完成', `完成章节：${chapterId}\n太棒啦～`);
    };

    this.core = new GameCore(chapterTemplates.natural, 'natural');
    this.core.load();
    this.refreshGoal();
    this.refreshButtons();
    this.refreshSlots();

    this.slotALabel!.node.on(Node.EventType.TOUCH_END, () => {
      this.slotA = null;
      this.refreshSlots();
    }, this);
    this.slotBLabel!.node.on(Node.EventType.TOUCH_END, () => {
      this.slotB = null;
      this.refreshSlots();
    }, this);
  }

  private refreshGoal() {
    if (this.goalLabel) {
      this.goalLabel.string = this.core.getCurrentGoalText();
    }
  }

  private refreshSlots() {
    if (this.slotALabel) {
      this.slotALabel.string = this.slotA ? `A = ${this.slotA}` : 'A = （空）';
    }
    if (this.slotBLabel) {
      this.slotBLabel.string = this.slotB ? `B = ${this.slotB}` : 'B = （空）';
    }
  }

  private refreshButtons() {
    if (!this.buttonsRoot || !this.elementButtonPrefab) return;

    this.buttonsRoot.removeAllChildren();

    for (const name of this.core.ownedOrder) {
      const node = instantiate(this.elementButtonPrefab);
      node.setParent(this.buttonsRoot);

      const icon = ELEMENT_ICONS[name] ?? '';
      const label = node.getComponentInChildren(Label);
      if (label) label.string = icon ? `${icon} ${name}` : name;

      const btn = node.getComponent(Button);
      if (btn) {
        btn.node.on(Button.EventType.CLICK, () => this.onPick(name), this);
      } else {
        node.on(Node.EventType.TOUCH_END, () => this.onPick(name), this);
      }
    }
    
  }

  private onPick(name: string) {
    if (!this.slotA) {
      this.slotA = name;
    } else if (!this.slotB) {
      this.slotB = name;
    } else {
      // 保留 B 作为上一次组合的后续，旧的 A 退回、最新选择成为 B
      this.slotA = this.slotB;
      this.slotB = name;
    }

    this.refreshSlots();

    if (this.slotA && this.slotB) {
      const r = this.core.tryCombine(this.slotA, this.slotB);
      if (!r.ok) {
        this.showPopup('🤔 没有反应', `${this.slotA} + ${this.slotB}\n换个组合试试～`);
      } else {
        const title = r.isNew ? '✨ 新发现' : '✨ 你以前做过';
        const desc = `${this.slotA} + ${this.slotB}\n→ ${r.result}\n\n${r.reason}`;
        this.showPopup(title, desc);

        if (r.isNew) {
          this.refreshButtons();
        }
        this.refreshGoal();
        this.core.save();

        if (this.core.isChapterCompleted()) {
          this.core.template.onComplete?.();
        }
      }

      this.slotA = null;
      this.slotB = null;
      this.refreshSlots();
    }
  }

  private showPopup(title: string, desc: string) {
    if (!this.popup || !this.popupTitle || !this.popupDesc) return;
    this.popupTitle.string = title;
    this.popupDesc.string = desc;
    this.popup.active = true;
  }
}
