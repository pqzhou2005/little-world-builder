import { _decorator, Component, Node, UITransform, ScrollView, Mask, director, Director } from 'cc';
const { ccclass } = _decorator;

function wb(n: Node | null) {
  if (!n) return 'null';
  const ui = n.getComponent(UITransform);
  if (!ui) return `${n.name} no UITransform`;
  const b = ui.getBoundingBoxToWorld();
  return `${n.name} size=(${ui.contentSize.width},${ui.contentSize.height}) worldBox=(${b.x.toFixed(1)},${b.y.toFixed(1)},${b.width.toFixed(1)},${b.height.toFixed(1)}) mask=${!!n.getComponent(Mask)}`;
}

function path(n: Node | null) {
  if (!n) return 'null';
  let p = n.name; let cur = n.parent;
  while (cur) { p = cur.name + '/' + p; cur = cur.parent; }
  return '//' + p;
}

@ccclass('ScrollViewSnapshot')
export class ScrollViewSnapshot extends Component {
  start() {
    // 等一帧，让 widget/layout/scrollview 都跑完
    director.once(Director.EVENT_AFTER_UPDATE, () => this.dump('after_update'));
    this.scheduleOnce(() => this.dump('t+0'), 0);
    this.scheduleOnce(() => this.dump('t+0.2'), 0.2);
  }

  dump(tag: string) {
    const sv = this.getComponent(ScrollView);
    console.log(`\n=== ScrollViewSnapshot ${tag} ===`);
    console.log('svNode:', wb(this.node), 'path=', path(this.node));
    console.log('sv.content:', sv?.content ? wb(sv.content) + ' path=' + path(sv.content) : 'null');

    // 3.8 里 ScrollView 的 view 一般不是公开字段，所以这里只做“尽力读取”
    const viewNode = (sv as any)?.view?.node as Node | undefined;
    console.log('sv.view:', viewNode ? wb(viewNode) + ' path=' + path(viewNode) : '(no sv.view)');

    const viewportByName = this.node.getChildByName('Viewport');
    console.log('child Viewport:', viewportByName ? wb(viewportByName) + ' path=' + path(viewportByName) : 'null');
    console.log('============================\n');
  }
}
